<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PWN lub Helion</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
    require('../connection.php');
    $conn = $GLOBALS['conn'];
    $query_text = <<<EOD
     SELECT ksiazki.Sygnatura 					 	     AS "signature",
            ksiazki.Tytul	 					         AS "title",
            CONCAT(ksiazki.Imie,' ',ksiazki.Nazwisko)    AS "author",
            ksiazki.Wydawnictwo					 	     AS "publishing",
            ksiazki.Rok_wyd						 	     AS "rel_date",
            ksiazki.Cena							     AS "price"
       FROM ksiazki
     WHERE (ksiazki.Wydawnictwo = "Helion" OR 
            ksiazki.Wydawnictwo = "PWN") AND
           (ksiazki.Rok_wyd > 1990 AND
            ksiazki.Rok_wyd < 2011)
     ORDER BY ksiazki.Rok_wyd ASC
    EOD;

    $query = $conn->query($query_text);
    ?>

    <table>
        <tr>
            <!-- <?php foreach(['Sygnatura','Tytuł','Autor','Wydawnictwo','Rok Wydania', 'Cena'] as $key => $value) echo "<th>$value</th>"?> -->
            <th>Sygnatura</th>
            <th>Tytuł</th>
            <th>Autor</th>
            <th>Wydawnictwo</th>
            <th>Rok Wydania</th>
            <th>Cena</th>
        </tr>
        <?php
        while ($row = $query->fetch_assoc()) {
            echo "<tr>";
            foreach ($row as $key => $value) {
                $val = $key === "price" ? floor($value).' zł '.fmod($value,2) : $value;
                echo "<td>".$value."</td>";
            }
            echo "</tr>";
        }
        ?>
    </table>
</body>

</html>